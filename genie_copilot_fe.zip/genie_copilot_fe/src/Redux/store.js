// import {createStore} from "redux";
import { legacy_createStore as createStore } from 'redux';
import Reducers from "./Reducers/Reducers";

import { persistReducer, persistStore } from "redux-persist";
import localStorage from 'redux-persist/es/storage';


const persistConfig = {
    key: "root",
    storage: localStorage,
    whitelist: ["LoginReducer", "Language", "Document", "NewChat"], // Specify the reducers to be persisted
  };
  
  const persistedReducer = persistReducer(persistConfig, Reducers);
  
  const store = createStore(
    persistedReducer,
    {},
    window.__REDUX_DEVTOOLS_EXTENSION__ && window.__REDUX_DEVTOOLS_EXTENSION__()
  );

  const persistor = persistStore(store);
  
  export { store, persistor };
  

// const store = createStore(
//     Reducers,
//     {},
//     window.__REDUX_DEVTOOLS_EXTENSION__ && window.__REDUX_DEVTOOLS_EXTENSION__()
// );

// export default store;
