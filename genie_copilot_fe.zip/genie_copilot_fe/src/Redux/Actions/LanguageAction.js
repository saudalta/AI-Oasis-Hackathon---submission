import {LanguageActionType} from "../Constants/LanguageActionType"
export const setSelectedLanguage = (language) => {
  return {
    type: LanguageActionType.SET_SELECTED_LANGUAGE,
    payload: language,
  };
};
