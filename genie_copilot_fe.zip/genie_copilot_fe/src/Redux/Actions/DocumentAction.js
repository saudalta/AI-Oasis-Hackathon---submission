import { DocumentActionType } from "../Constants/DocumentActionType";

export const setSelectedDocument = (doc) => {
  return {
    type: DocumentActionType.SET_SELECTED_DOCUMENT,
    payload: doc,
  };
};
