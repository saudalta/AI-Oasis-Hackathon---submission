import { NewChatActionType } from "../Constants/NewChatActionType";

export const setNewChat = (chat) => {
  return {
    type: NewChatActionType.SET_NEW_CHAT,
    payload: chat,
  };
};

export const setNewChatID = (chatId) => {
  return {
    type: NewChatActionType.SET_NEW_CHAT_ID,
    payload: chatId,
  };
};

export const setChatHistory = (history) => ({
  type: NewChatActionType.SET_CHAT_HISTORY,
  payload: history,
});
