import {combineReducers} from "redux";
import { LoginReducer } from "./LoginReducer";
import { LanguageReducer } from "./LanguageReducer";
import { DocumentReducer } from "./DocumentReducer";
import { NewChatReducer } from "./NewChatReducer";


const Reducers = combineReducers({
    LoginReducer: LoginReducer,
    Language: LanguageReducer,
    Document: DocumentReducer,
    NewChat: NewChatReducer,
});

export default Reducers;
