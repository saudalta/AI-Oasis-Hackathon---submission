import { DocumentActionType } from "../Constants/DocumentActionType";

const initialState = {
  selectedDocument: null,
};

export const DocumentReducer = (state = initialState, action) => {
  switch (action.type) {
    case DocumentActionType.SET_SELECTED_DOCUMENT:
      return { ...state, selectedDocument: action.payload };
    default:
      return state;
  }
};
