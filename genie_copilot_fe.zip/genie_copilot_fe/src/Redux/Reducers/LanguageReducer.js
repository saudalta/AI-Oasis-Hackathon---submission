import {LanguageActionType} from "../Constants/LanguageActionType";

const initialState = {
  selectedLanguage: 'english',
};

export const LanguageReducer = (state = initialState, action) => {
  switch (action.type) {
    case LanguageActionType.SET_SELECTED_LANGUAGE:
      return {...state, selectedLanguage: action.payload};
    default:
      return state;
  }
};
