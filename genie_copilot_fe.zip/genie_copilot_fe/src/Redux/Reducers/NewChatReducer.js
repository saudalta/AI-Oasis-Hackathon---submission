import { NewChatActionType } from "../Constants/NewChatActionType";

const initialState = {
  newChat: false,
  chatID:"",
  chatHistory: [],
};

// export const NewChatReducer = (state = initialState, action) => {
//   switch (action.type) {
//     case NewChatActionType.SET_NEW_CHAT:
//       return { ...state, setNewChat: action.payload };
//     default:
//       return state;
//   }
// };


export const NewChatReducer = (state = initialState, action) => {
  switch (action.type) {
    case NewChatActionType.SET_NEW_CHAT:
      return {
        ...state,
        newChat: action.payload,
      };

    case NewChatActionType.SET_NEW_CHAT_ID:
      return {
        ...state,
        chatID: action.payload,
      };
    
      case NewChatActionType.SET_CHAT_HISTORY:
      return {
        ...state,
        chatHistory: action.payload,
      };

    default:
      return state;
  }
};