export const LanguageActionType = {
    SET_SELECTED_LANGUAGE: "SET_SELECTED_LANGUAGE",
  };
  