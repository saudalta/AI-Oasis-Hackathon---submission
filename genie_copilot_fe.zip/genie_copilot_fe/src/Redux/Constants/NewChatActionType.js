export const NewChatActionType = {
    SET_NEW_CHAT: "SET_NEW_CHAT",
    SET_NEW_CHAT_ID: "SET_NEW_CHAT_ID",
    SET_CHAT_HISTORY: "SET_CHAT_HISTORY",
  };
  