export const DocumentActionType = {
  SET_SELECTED_DOCUMENT: "SET_SELECTED_DOCUMENT",
};
