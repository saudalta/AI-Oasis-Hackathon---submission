export const LoginActionType = {
  SET_IS_LOGIN: "SET_IS_LOGIN",
  SET_TOKEN: "SET_TOKEN",
  SET_USER: "SET_USER",
  LOGOUT: "LOGOUT",
};
