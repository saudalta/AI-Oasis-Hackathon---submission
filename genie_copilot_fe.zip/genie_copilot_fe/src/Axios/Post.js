import axios from "axios";
import { BASEURL } from "./EndPoints";


export const Post = (
    endPoint,
    data,
    encrypted = true,
    token,
    // dispatch,
    // setToken,
    isMultiPart
  ) => {
    let headers;
    if (encrypted) {
      headers = {
        withCredentials: true,
        Accept: "application/json",
        Authorization: "Bearer " + token,
        "Content-Type": isMultiPart ? "multipart/form-data" : "application/json",
        "ngrok-skip-browser-warning": true,
      };
    } else {
      headers = {
        // withCredentials: true,
        Accept: "application/json",
        // "Content-Type": "multipart/form-data",
        "Content-Type": isMultiPart ? "multipart/form-data" : "application/json",
        "ngrok-skip-browser-warning": true,
      };
    }
  
    let url = BASEURL + endPoint;
  
    let response = axios.post(url, data, { headers });
  
    return response.catch((error) => {
      if (error?.response?.code === 401 || error?.response?.status === 401) {
        // dispatch(setToken(""));
        window.location.replace("/");
        return error;
      } else {
        return response;
      }
    });
  };
  