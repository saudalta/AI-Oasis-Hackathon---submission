import axios from "axios";
import { BASEURL } from "./EndPoints";

export const Delete = (
  endPoint,
  data,
  encrypted = true,
  token,
  // dispatch,
  // setToken,
  isMultiPart
) => {
  let headers;
  if (encrypted) {
    headers = {
      withCredentials: true,
      Accept: "application/json",
      Authorization: "Bearer " + token,
      "Content-Type": isMultiPart ? "multipart/form-data" : "application/json",
      "ngrok-skip-browser-warning": true,
    };
  } else {
    headers = {
      // withCredentials: true,
      // Accept: "application/json",
      "Content-Type": "multipart/form-data",
      "ngrok-skip-browser-warning": true,
    };
  }

  let url = BASEURL + endPoint;

  let response = axios.delete(url, { headers });

  return response.catch((error) => {
    if (error?.response?.statusCode === 401 || error?.response?.status === 401) {
      // dispatch(setToken(""));
      window.location.replace("/");
      return error;
    } else {
      return response;
    }
  });
};
