export const BASEURL = "https://9e37-8-213-38-79.ngrok-free.app"; //staging

export const BASEURL1 = "https://0271-2001-16a2-c2d8-1892-546f-1783-d8e0-192b.ngrok-free.app/api"; //staging

export const ENDPOINTS = {
  PING: "/ping",
  COMPLETIONS: "/v1/completions",
  COMPLETIONS_WITH_DOCUMENTS: "/v1/chat/completions",
  INGEST: "/v1/ingest",
  INGEST_LIST: "/v1/ingest/list",
  DELETE_LIST_DOCUMENT: "/v1/ingest/",
};

export const AUTH_ENDPOINTS = {
  REGISTER: "/register",
  LOGIN: "/login",
  CREATE_CHAT: "/create/chat",
  CREATE_CHAT_HISTORY_LOGS: "/create/chat/logs",
  
  GET_CHAT_LIST: "/chat/list",
  GET_CHAT_SINGLE_DETAIL: "/chat/single/details",
};
