import axios from "axios";
import { BASEURL } from "./EndPoints";
// import { setIsLogin, setToken, setUser } from "../Redux/Actions/LoginActions";

export const Get = (
  endPoint,
  encrypted,
  token
  // dispatch,
  // setToken,
) => {
  let headers;

  if (endPoint.includes("undefined")) {
    return;
  }

  if (encrypted) {
    headers = {
      Accept: "application/json",
      Authorization: "Bearer " + token,
      "Content-Type": "application/json",
      "ngrok-skip-browser-warning": true,
    };
  } else {
    headers = {
      withCredentials: true,
      Accept: "application/json",
      // 'Content-Type': "application/x-www-form-urlencoded",
      "Content-Type": "application/json",
      "ngrok-skip-browser-warning": true,
    };
  }
  let url = BASEURL + endPoint;
  let response = axios.get(url, { headers });
  return response.catch((error) => {
    console.log("error in get=", error);

    if (error?.response?.status === 401 || error?.response?.status === 401) {
      // dispatch(setToken(""));
      window.location.replace("/");
      return error;
    } else {
      return response;
    }
  });
};
