import React from "react";
import { BrowserRouter, Route, Routes } from "react-router-dom";

import Layout from "../Components/DashboardLayoutComponents/Layout";
import Home from "../Pages/DashboardPages/Home";
import Login from "../Pages/Login";
import Signup from "../Pages/Signup";

const AppRoutes = () => {
  //   const LoginReducer = useSelector((state) => state?.LoginReducer);
  //   console.log("LoginReducer >>>", LoginReducer.isLogin);

  return (
    <BrowserRouter>
      <Routes>
        <Route exact path="/" element={<Login />} />
        <Route exact path="/login" element={<Login />} />
        <Route path="/signup" element={<Signup />} />
        <Route path="dashboard/" element={<Layout />}>
          <Route path="home" element={<Home />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
};

export default AppRoutes;
