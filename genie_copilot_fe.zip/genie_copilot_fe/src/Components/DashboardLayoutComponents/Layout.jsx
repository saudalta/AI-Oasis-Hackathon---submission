import React, { useEffect, useState } from "react";
import { Outlet } from "react-router-dom";
import LeftSidebar from "./LeftSidebar";
import RightSidebar from "./RightSidebar";
import { useSelector } from "react-redux";
// import { determineDictionary } from "../../Lib/determineDictionary";

const Layout = () => {
  const languageStore = useSelector(
    (state) => state?.Language?.selectedLanguage
  );

  const [activeLanguage, setActiveLanguage] = useState(
    languageStore || "english"
  );
  // const [activeLanguageData, setActiveLanguageData] = useState(
  //   determineDictionary(activeLanguage)
  // );

  useEffect(() => {
    // setActiveLanguageData(determineDictionary(languageStore));
    setActiveLanguage(activeLanguage);
    // eslint-disable-next-line
  }, [languageStore]);

  // console.log(languageStore)
  
  const sidebarStyle = {
    boxShadow: "inset 0 -2px 4px rgba(255, 255, 255, 0.3), 0 2px 5px rgba(0, 0, 0, 0.1), 0 10px 10px rgba(0, 0, 0, 0.05)",
    transition: "box-shadow 0.3s ease"
  };

  return (
    <>
     <div className={`flex h-screen bg-white ${languageStore === "arabic" && "flex-row-reverse"}`}>
        {/* Left Sidebar */}
        <div 
          className="h-screen w-2/12"
          style={sidebarStyle}
        >
          <LeftSidebar/>
        </div>

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto">
          <Outlet />
        </div>
        <div 
          className="h-screen w-2/12"
          style={sidebarStyle}
        >
          <RightSidebar/>
        </div>
      </div>
    </>
  );
};

export default Layout;
