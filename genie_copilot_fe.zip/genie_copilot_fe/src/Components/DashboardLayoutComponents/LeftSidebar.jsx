import React, { useEffect, useState } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";

import {
  // faSearch,
  faChevronRight,
  faChevronDown,
  faFileArchive,
  faLink,
  faTable,
  faDatabase,
  faEarth,
  faExternalLinkAlt,
  faSignOutAlt,
  faXmark,
  faChevronLeft,
} from "@fortawesome/free-solid-svg-icons";

import IconLLM from "../../Assets/Icons/icon-llm.svg";
import IconKnowldgeBases from "../../Assets/Icons/icon-knowledge-bases.svg";
import { faMoon, faTrashCan } from "@fortawesome/free-regular-svg-icons";
import { determineDictionary } from "../../Lib/determineDictionary";
import { setSelectedLanguage } from "../../Redux/Actions/LanguageAction";

import { Get } from "../../Axios/Get";
import { ENDPOINTS } from "../../Axios/EndPoints";
import { Delete } from "../../Axios/Delete";
import { setSelectedDocument } from "../../Redux/Actions/DocumentAction";
import { logout } from "../../Redux/Actions/LoginActions";
import { setChatHistory, setNewChat, setNewChatID } from "../../Redux/Actions/NewChatAction";

const LeftSidebar = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  // const reduxData = useSelector((state) => state?.LoginReducer);
  // console.log("reduxData >>>", reduxData)
  const languageStore = useSelector(
    (state) => state?.Language?.selectedLanguage
  );
  // console.log("languageStore >>>", languageStore)

  const [showSubMenu, setShowSubMenu] = useState(false);
  const [showDocMenu, setShowDocMenu] = useState(false);
  const [activeLanguage, setActiveLanguage] = useState(
    languageStore || "english"
  );

  const [activeLanguageData, setActiveLanguageData] = useState(
    determineDictionary(activeLanguage)
  );

  const [documents, setDocuments] = useState([]);

  const fetchDocuments = () => {
    Get(ENDPOINTS.INGEST_LIST, false, "")
      .then((res) => {
        // console.log("response from api gettin docs >>>", res?.data?.data);
        setDocuments(res?.data?.data);
      })
      .catch((error) => {
        console.log("error in getting documents", error);
      });
  };

  useEffect(() => {
    fetchDocuments();
    // eslint-disable-next-line
  }, []);

  useEffect(() => {
    setActiveLanguageData(determineDictionary(activeLanguage));
    // eslint-disable-next-line
  }, [languageStore]);

  const handleSubMenuToggle = () => {
    setShowSubMenu(!showSubMenu);
  };

  const handleSubDocToggle = () => {
    setShowDocMenu(!showDocMenu);
  };

  const onClickDeleteDocument = (doc) => {
    // console.log("documnet clicked with name >", doc?.doc_id);
    Delete(ENDPOINTS.DELETE_LIST_DOCUMENT + `${doc?.doc_id}`, false, "", false)
      .then((res) => {
        // console.log("response from delete api >>>", res);
        fetchDocuments();
      })
      .catch((error) => {
        console.log("error in deleting documents", error);
      });
  };

  const onClickChangeLanguage = () => {
    setActiveLanguageData(determineDictionary(activeLanguage));
    setActiveLanguage(activeLanguage === "english" ? "arabic" : "english");
    dispatch(
      setSelectedLanguage(activeLanguage === "english" ? "arabic" : "english")
    );
  };

  const onClickLogout = () => {
    dispatch(logout())
    dispatch(setNewChat(true));
    dispatch(setNewChatID(""));
    dispatch(setChatHistory([]));
    
    navigate("/");
  };

  // console.log(languageStore)

  //   const logOut = () => {
  //     dispatch(logout());
  //     dispatch(SetHashtagsData([]))
  //     dispatch(SetMentionsData([]))
  //     dispatch(clearAnalysisStates({
  //         analysisStates: null
  //     }))
  //     dispatch(clearUserFilterStates({
  //         userFilterStates: null
  //     }))
  //     const preparedLanguage = `/${activeLanguage === "english" ? "en" : "ar"}`;
  //     router.replace("/signin" + preparedLanguage);
  // };

  const SubmenuItem = ({ icon, text, onClick, isOpen }) => (
    <>
      <div
        role="button"
        className={`border flex items-center justify-between px-3 py-2 hover:bg-slate-100 rounded-sm ${languageStore === "arabic" && "flex-row-reverse"}`}
        onClick={onClick}
      >
        <div className={`flex items-center gap-2 ${languageStore === "arabic" && "flex-row-reverse"}`}>
          <FontAwesomeIcon icon={icon} className="text-gray-500" />
          <div className="text text-sm font-normal">{text}</div>
        </div>
        <div>
          <FontAwesomeIcon
            icon={isOpen ? faChevronDown : languageStore === "arabic" ? faChevronLeft :faChevronRight}
            className="text-gray-500"
            onClick={onClick}
          />
        </div>
      </div>
      {isOpen && (
        <>
          <div className="ma max-h-32 px-3 overflow-y-auto w-full flex flex-col gap-2 ps-1">
            {documents?.map((doc, index) => {
              return (
                <div className="border border-1 p-1" key={index}>
                  <div
                    role="button"
                    onClick={() => {
                      // onClickDocument(doc?.name, doc?.id);
                      // console.log("document clicked");
                      dispatch(setSelectedDocument(doc));
                    }}
                  >
                    <div className="flex items-center gap-3">
                      <div className="text-xs text-nowrap">
                        {doc?.doc_metadata?.file_name}
                      </div>
                      <div
                        className="flex items-center justify-center bg-red-500 rounded-full p-1"
                        role="button"
                        onClick={(e) => {
                          e.preventDefault();
                          onClickDeleteDocument(doc);
                        }}
                      >
                        <FontAwesomeIcon
                          icon={faXmark}
                          className=" text-white"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </>
      )}
    </>
  );

  return (
    <div className="p-5 h-full min-h-full overflow-y-auto">
      <div className="h-full flex flex-col items-start justify-between">
        <div className="flex flex-col gap-5 w-full">
          <div className={`bg-gray-100 w-full rounded-md flex flex-col xl:flex-row items-center xl:items-start gap-3 p-2 ${languageStore === "arabic" && "xl:flex-row-reverse"}`}>
            <div className="h-11 w-11 bg-red-500 rounded-full">
              <img
                src={"https://avatar.iran.liara.run/public/40"}
                alt="user"
                className="h-11 w-11 object-cover"
              />
            </div>
            <div className="flex flex-col gap-1 items-center xl:items-start text-center">
              <div className="font-bold text-sm">
                {activeLanguageData?.Saud_Altamimi}
              </div>
              <div className="font-medium text-xs">
                {activeLanguageData?.My_Account}
              </div>
            </div>
          </div>
          {/* <div className="bg-gray-100 w-full rounded-3xl flex gap-3 p-2 items-center justify-center px-2">
            <FontAwesomeIcon icon={faSearch} className="text-gray-500" />
            <input
              type="search"
              placeholder="Search Nodes"
              className="flex-grow  rounded-md focus:outline-none bg-transparent"
              style={{ border: "none" }}
            />
          </div> */}
          <div className={`flex items-center justify-between mt-5 ${languageStore === "arabic" && "flex-row-reverse"}`}>
            <div className={`flex items-center gap-2 ${languageStore === "arabic" && "flex-row-reverse"}`}>
              <img src={IconLLM} alt="icon" />
              <div className="text text-sm font-normal">
                {activeLanguageData?.LLMs}
              </div>
            </div>
            <div>
              <FontAwesomeIcon
                icon={languageStore === "arabic" ? faChevronLeft :faChevronRight}
                className="text-gray-500"
              />
            </div>
          </div>
          <div
            role="button"
            className={`flex items-center justify-between transition-all duration-300 ${languageStore === "arabic" && "flex-row-reverse"}`}
            onClick={handleSubMenuToggle}
          >
            <div className={`flex items-center gap-2 ${languageStore === "arabic" && "flex-row-reverse"}`}>
              <img src={IconKnowldgeBases} alt="icon" />
              <div className="text text-sm font-normal">
                {activeLanguageData?.Knowledge_Bases}
              </div>
            </div>
            <div>
              <FontAwesomeIcon
                icon={showSubMenu ? faChevronDown : languageStore === "arabic" ? faChevronLeft :faChevronRight}
                className="text-gray-500"
                onClick={handleSubMenuToggle}
              />
            </div>
          </div>
          {showSubMenu && (
            <div className="border-l mx-3 pl-3">
              <div className="flex flex-col gap-2">
                <SubmenuItem
                  icon={faFileArchive}
                  text={activeLanguageData?.Documents_nav}
                  onClick={handleSubDocToggle}
                  isOpen={showDocMenu}
                />
                <div
                  role="button"
                  className={`border flex items-center justify-between px-3 py-2 hover:bg-slate-100 rounded-sm ${languageStore === "arabic" && "flex-row-reverse"}`}                  
                  // onClick={onClick}
                >
                  <div className={`flex items-center gap-2 ${languageStore === "arabic" && "flex-row-reverse"}`}>
                    <FontAwesomeIcon icon={faLink} className="text-gray-500" />
                    <div className="text text-sm font-normal">
                      {activeLanguageData?.URLs}
                    </div>
                  </div>
                </div>
                <div
                  role="button"
                  className={`border flex items-center justify-between px-3 py-2 hover:bg-slate-100 rounded-sm ${languageStore === "arabic" && "flex-row-reverse"}`}
                  // onClick={onClick}
                >
                  <div className={`flex items-center gap-2 ${languageStore === "arabic" && "flex-row-reverse"}`}>
                    <FontAwesomeIcon icon={faTable} className="text-gray-500" />
                    <div className="text text-sm font-normal">
                      {activeLanguageData?.Tables}
                    </div>
                  </div>
                </div>
                <div
                  role="button"
                  className={`border flex items-center justify-between px-3 py-2 hover:bg-slate-100 rounded-sm ${languageStore === "arabic" && "flex-row-reverse"}`}
                  // onClick={onClick}
                >
                  <div className={`flex items-center gap-2 ${languageStore === "arabic" && "flex-row-reverse"}`}>
                    <FontAwesomeIcon
                      icon={faDatabase}
                      className="text-gray-500"
                    />
                    <div className="text text-sm font-normal">
                      {activeLanguageData?.Data}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
        <div className="border-t w-full py-3 flex flex-col gap-3 pt-10">
          <div role="button" className={`flex items-center gap-3 ${languageStore === "arabic" && "flex-row-reverse"}`}>
            <FontAwesomeIcon icon={faTrashCan} className="text-gray-500" />
            <div>{activeLanguageData?.Clear_all_conversations}</div>
          </div>
          <div role="button" className={`flex items-center gap-3 ${languageStore === "arabic" && "flex-row-reverse"} `}>
            <FontAwesomeIcon icon={faMoon} className="text-gray-500" />
            <div>{activeLanguageData?.Switch_Light_Mode}</div>
          </div>
          <div
            role="button"
            className={`flex items-center gap-3 ${languageStore === "arabic" && "flex-row-reverse"}`}
            onClick={onClickChangeLanguage}
          >
            <FontAwesomeIcon icon={faEarth} className="text-gray-500" />
            <div>{activeLanguageData?.Arabic_Language}</div>
          </div>
          <div role="button" className={`flex items-center gap-3 ${languageStore === "arabic" && "flex-row-reverse"}`}>
            <FontAwesomeIcon
              icon={faExternalLinkAlt}
              className="text-gray-500"
            />
            <div>{activeLanguageData?.Updates_FAQ}</div>
          </div>
          <div
            role="button"
            className={`flex items-center gap-3 text-red-400 mt-5 ${languageStore === "arabic" && "flex-row-reverse"}`}
            onClick={onClickLogout}
          >
            <FontAwesomeIcon icon={faSignOutAlt} />
            <div>{activeLanguageData?.Log_out}</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LeftSidebar;
