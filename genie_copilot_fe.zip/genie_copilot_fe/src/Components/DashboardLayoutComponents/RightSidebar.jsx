import React, { useEffect, useState } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
// import { useNavigate } from "react-router-dom";
import { faMessage, faPlus } from "@fortawesome/free-solid-svg-icons";
import { determineDictionary } from "../../Lib/determineDictionary";
import { useDispatch, useSelector } from "react-redux";
import {
  setNewChat,
  setChatHistory,
  setNewChatID,
} from "../../Redux/Actions/NewChatAction";

import { setSelectedDocument } from "../../Redux/Actions/DocumentAction";
import axios from "axios";
import { AUTH_ENDPOINTS, BASEURL1 } from "../../Axios/EndPoints";

const RightSidebar = () => {
  const dispatch = useDispatch();
  // const navigate = useNavigate();
  // const dispatch = useDispatch();
  // const reduxData = useSelector((state) => state?.LoginReducer);
  const languageStore = useSelector(
    (state) => state?.Language?.selectedLanguage
  );

  const authStore = useSelector((state) => state?.LoginReducer);
  // const chatHistory = useSelector((state) => state.NewChat);

  // console.log("chatHistory >>>", chatHistory)

  const [activeLanguage, setActiveLanguage] = useState(
    languageStore || "english"
  );
  const [activeLanguageData, setActiveLanguageData] = useState(
    determineDictionary(activeLanguage)
  );
  const [chatList, setChatList] = useState([]);

  const fetchChatList = async () => {
    try {
      const token = authStore?.token; // Replace with your actual access token
      const response = await axios.get(
        BASEURL1 + AUTH_ENDPOINTS.GET_CHAT_LIST,
        {
          headers: {
            Accept: "application/json",
            Authorization: "Bearer " + token,
            "Content-Type": "application/json",
            "ngrok-skip-browser-warning": true,
          },
        }
      );

      if (response?.data?.success) {
        // console.log("response gettin chats >>>>", response?.data?.data);
        setChatList(response?.data?.data);
      }
    } catch (error) {
      console.error("Error fetching chat list:", error);
    }
  };

  useEffect(() => {
    setActiveLanguageData(determineDictionary(languageStore));
    setActiveLanguage(activeLanguage);
    // eslint-disable-next-line
  }, [languageStore]);

  useEffect(() => {
    fetchChatList();
    // eslint-disable-next-line
  }, []);

  // console.log("reduxData >>>", reduxData)
  // console.log("languageStore >>>", languageStore)

  const createNewChat = async () => {
    const token = authStore?.token;

    try {
      const response = await axios.post(
        BASEURL1 + AUTH_ENDPOINTS.CREATE_CHAT,
        null,
        {
          headers: {
            Accept: "application/json",
            Authorization: "Bearer " + token,
            "Content-Type": "application/json",
            "ngrok-skip-browser-warning": true,
          },
        }
      );

      // console.log("API Response:", response?.data?.data);
      if (response?.data?.success) {
        // const newChatId = response?.data?.data?.chat_id;
        const newChatId = response?.data?.data?.id;
        dispatch(setChatHistory([])); // Clear chat history
        dispatch(setNewChat(true));
        dispatch(setNewChatID(newChatId));
        dispatch(setSelectedDocument(null));
      }
      // Handle success or other logic based on the response
    } catch (error) {
      console.error("API Error:", error?.response);
    }
  };

  const onClickNewChat = () => {
    // console.log("new chat")
    createNewChat();
    fetchChatList();
    // dispatch(setNewChat(true));
    // dispatch(setSelectedDocument(null));
  };

  const fetchSingleChat = async (id) => {
    try {
      const token = authStore?.token; // Replace with your actual access token
      const response = await axios.get(
        BASEURL1 + AUTH_ENDPOINTS.GET_CHAT_SINGLE_DETAIL + `/${id}`,
        {
          headers: {
            Accept: "application/json",
            Authorization: "Bearer " + token,
            "Content-Type": "application/json",
            "ngrok-skip-browser-warning": true,
          },
        }
      );

      if (response?.data?.success) {
        console.log("response getting sigle chat >>>>", response?.data?.data);
        const chatHistory = response?.data?.data;
        dispatch(setChatHistory(chatHistory));
      }
    } catch (error) {
      console.error("Error fetching chat detail:", error);
    }
  };
  const onClickSingleChat = (chat) => {
    fetchSingleChat(chat?.chat_id);
  };

  return (
    <>
      <div className="p-5 h-full min-h-full overflow-y-auto">
        <div className="h-full flex flex-col items-start justify-start gap-5">
          <div className="w-full items-center justify-center flex">
            <div
              className="bg-slate-100 w-fit px-3 py-2 rounded-full flex items-center gap-3 font-bold"
              role="button"
              onClick={onClickNewChat}
            >
              <div className="text-nowrap">
                {activeLanguageData?.Start_a_new_Chat}
              </div>
              <FontAwesomeIcon
                icon={faPlus}
                className="text-gray-500 font-bold"
              />
            </div>
          </div>
          <div
            className={`w-full flex  ${
              languageStore === "english" ? "justify-start" : "justify-end"
            }`}
          >
            <div className={`font-14 font-bold`}>
              {activeLanguageData?.Recent_Talks}
            </div>
          </div>
          <div className="flex flex-col gap-2 items-start w-full h-3/4 overflow-y-auto pe-3">
            {chatList?.map((chat, index) => (
              <div
                key={index}
                className={`w-full flex items-center gap-3 ${
                  languageStore === "english"
                    ? "justify-start flex-row"
                    : "justify-start flex-row-reverse"
                }`}
                role="button"
                onClick={(e) => {
                  e.preventDefault();
                  onClickSingleChat(chat);
                }}
              >
                <FontAwesomeIcon icon={faMessage} className="text-gray-500" />
                {/* <div className="flex items-start mb-2">{chat?.prompt || "TestPrompt"}</div> */}
                <div className="flex items-start mb-2 truncate truncate-overflow w-11/12 whitespace-nowrap">
                  {chat?.prompt !== "undefined"? chat?.prompt : "New Chat"}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </>
  );
};

export default RightSidebar;
