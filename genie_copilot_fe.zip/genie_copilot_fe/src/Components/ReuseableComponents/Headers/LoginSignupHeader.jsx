import React from "react";
import { Link } from "react-router-dom";
import logo from "../../../Assets/Logos/Logo Mark.svg"

const LoginSignupHeader = (props) => {
  const { heading, paragraph, linkName, linkUrl = "#" } = props;

  return (
    <div className="mb-10">
      <div className="flex justify-center">
        <img
          alt="logo"
          className="h-14 w-14"
          src={logo}
        />
      </div>
      <h2 className="mt-6 text-center text-3xl font-extrabold text-gray-900">
        {heading}
      </h2>
      <p className="text-center text-sm text-gray-600 mt-5">
        {paragraph}{" "}
        <Link
          to={linkUrl}
          className="font-medium text-cyan-400 hover:text-cyan-400"
          // style={{
          //   color:"#00d9dd"
          // }}
        >
          {linkName}
        </Link>
      </p>
    </div>
  );
};

export default LoginSignupHeader;
