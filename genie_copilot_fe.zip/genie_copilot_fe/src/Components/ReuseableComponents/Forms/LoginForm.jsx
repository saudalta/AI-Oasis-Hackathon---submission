import React, { useState } from "react";
import { loginFields } from "../../../Utils/JS/formFields";
import Input from "../Inputs/Input";
// import FormExtra from "./FormExtra";
import FormAction from "./FormAction";

import { useNavigate } from "react-router-dom";
import axios from "axios";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { AUTH_ENDPOINTS, BASEURL1 } from "../../../Axios/EndPoints";


import { useDispatch } from "react-redux";
import { setIsLogin, setToken, setUser } from "../../../Redux/Actions/LoginActions";

const LoginForm = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const fields = loginFields;
  let fieldsState = {};
  fields.forEach((field) => (fieldsState[field.id] = ""));

  const [loginState, setLoginState] = useState(fieldsState);
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    setLoginState({ ...loginState, [e.target.id]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // navigate("dashboard/home");
    authenticateUser();
  };

  //Api call will be here
  const authenticateUser = async () => {
    setLoading(true);
    const formData = new FormData();

    formData.append("email", loginState?.email);
    formData.append("password", loginState?.password);

    try {
      const response = await axios.post(
        BASEURL1 + AUTH_ENDPOINTS.LOGIN,
        formData
      );

      // console.log("API Response:", response?.data?.data);
      if(response?.data?.success){
        dispatch(setIsLogin(true));
        dispatch(setToken(response?.data?.data?.token));
        dispatch(setUser(response?.data?.data));
        navigate("dashboard/home");
        setLoading(false);
      }
      // Handle success or other logic based on the response
    } catch (error) {
      // console.error("API Error:", error?.response?.data?.message);
      toast.error("Invalid credentials!");
      setLoading(false);
    }
  };

  return (
    <>
      <form className="mt-8 space-y-6" onSubmit={handleSubmit}>
        <div className="-space-y-px">
          {fields.map((field) => (
            <Input
              key={field.id}
              handleChange={handleChange}
              value={loginState[field.id]}
              labelText={field.labelText}
              labelFor={field.labelFor}
              id={field.id}
              name={field.name}
              type={field.type}
              isRequired={field.isRequired}
              placeholder={field.placeholder}
            />
          ))}
        </div>

        {/* <FormExtra /> */}
        <FormAction handleSubmit={handleSubmit} text="Login" loading={loading}/>
      </form>
      <ToastContainer />
    </>
  );
};

export default LoginForm;
