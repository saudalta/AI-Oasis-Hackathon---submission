import React from "react";
import SmallLoader from "../../Loader/SmallLoader";

const FormAction = (props) => {
  const {
    handleSubmit,
    type = "Button",
    action = "submit",
    text,
    loading,
  } = props;

  return (
    <>
      {type === "Button" ? (
        <button
          type={action}
          className="group relative w-full flex justify-center py-2 px-4 border border-transparent text-sm font-medium rounded-md text-white bg-cyan-400 hover:bg-cyan-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-cyan-400 mt-10"
          onSubmit={handleSubmit}
        >
          {loading ? (
            <>
              <SmallLoader />
            </>
          ) : (
            <>{text}</>
          )}
        </button>
      ) : (
        <></>
      )}
    </>
  );
};

export default FormAction;
