import React, { useState } from "react";
import { signupFields } from "../../../Utils/JS/formFields";
import Input from "../Inputs/Input";
import FormAction from "./FormAction";
import { AUTH_ENDPOINTS, BASEURL1 } from "../../../Axios/EndPoints";

import { useNavigate } from "react-router-dom";
import axios from "axios";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const SignupForm = () => {
  const navigate = useNavigate();
  const fields = signupFields;
  let fieldsState = {};

  fields.forEach((field) => (fieldsState[field.id] = ""));

  const [signupState, setSignupState] = useState(fieldsState);
  const [loading, setLoading] = useState(false);

  const handleChange = (e) =>
    setSignupState({ ...signupState, [e.target.id]: e.target.value });

  const handleSubmit = (e) => {
    e.preventDefault();

    createAccount();
  };

  //handle Signup API Integration here
  const createAccount = async () => {
    setLoading(true);
    const formData = new FormData();

    formData.append("first_name", signupState?.firstname);
    formData.append("last_name", signupState?.lastname);
    formData.append("user_name", signupState?.username);
    formData.append("email", signupState?.email);
    formData.append("password", signupState?.password);

    try {
      const response = await axios.post(
        BASEURL1 + AUTH_ENDPOINTS.REGISTER,
        formData
      );

      // console.log("API Response:", response?.data?.success);
      if (response?.data?.success) {
        toast.success("Account created successfully!");
        navigate("/");
        setLoading(false)
      }
      // Handle success or other logic based on the response
    } catch (error) {
      console.error("API Error:", error?.response?.data?.message);
      toast.error(error?.response?.data?.message || "Please try again!");
      setLoading(false);
    }
  };

  return (
    <>
      <form className="mt-8 space-y-6" onSubmit={handleSubmit}>
        <div className="">
          {fields.map((field) => (
            <Input
              key={field.id}
              handleChange={handleChange}
              value={signupState[field.id]}
              labelText={field.labelText}
              labelFor={field.labelFor}
              id={field.id}
              name={field.name}
              type={field.type}
              isRequired={field.isRequired}
              placeholder={field.placeholder}
            />
          ))}
          <FormAction handleSubmit={handleSubmit} text="Signup" loading={loading}/>
        </div>
      </form>
      <ToastContainer />
    </>
  );
};

export default SignupForm;
