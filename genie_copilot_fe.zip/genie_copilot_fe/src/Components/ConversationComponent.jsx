import { faRandom } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import React, { useEffect, useState } from "react";
import SkeletonLoader from "./Loader/SkeletonLoader";

const ConversationComponent = (props) => {
  const { conversation, typewriting, isLast, loading} = props;
  // console.log("conversation?.prompt >>", conversation?.prompt);
  const [cleanedResponse, setCleanedResponse] = useState("");
  const [cleanedResponseHistory, setCleanedResponseHistory] = useState("");
  const [displayedText, setDisplayedText] = useState("");
  const [textDirection, setTextDirection] = useState("ltr");

  useEffect(() => {
    const cleanedText = conversation?.response?.replace(/^\((.*)\)$/, "$1");
    const chatHistoryText = conversation?.system_prompt?.replace(
      /^\((.*)\)$/,
      "$1"
    );

    setCleanedResponse(cleanedText);
    setCleanedResponseHistory(chatHistoryText);

    // Determine text direction based on the presence of Arabic characters
    setTextDirection(detectTextDirection(cleanedText || chatHistoryText));

    // Cleanup effect on component unmount
    return () => {
      // Cleanup if needed
    };
  }, [conversation]);

  // useEffect(() => {
  //   if (cleanedResponse) {
  //     let currentIndex = 0;
  //     const intervalId = setInterval(() => {
  //       setDisplayedText(cleanedResponse.substring(0, currentIndex));
  //       currentIndex++;

  //       if (currentIndex > cleanedResponse.length) {
  //         clearInterval(intervalId);
  //       }
  //     }, 10); // Adjust the typing speed (interval) as needed

  //     return () => clearInterval(intervalId); // Cleanup on component unmount
  //   }
  // }, [cleanedResponse]);

  useEffect(() => {
    if (isLast && typewriting && cleanedResponse) {
      let currentIndex = 0;
      const intervalId = setInterval(() => {
        setDisplayedText(cleanedResponse.substring(0, currentIndex));
        currentIndex++;

        if (currentIndex > cleanedResponse.length) {
          clearInterval(intervalId);
        }
      }, 10); // Adjust the typing speed (interval) as needed

      return () => clearInterval(intervalId); // Cleanup on component unmount
    }
  }, [isLast, typewriting, cleanedResponse]);

  const detectTextDirection = (text) => {
    // You can use a more sophisticated logic to detect RTL based on the language or text content
    const arabicRegex = /[\u0600-\u06FF]/;
    return arabicRegex.test(text) ? "rtl" : "ltr";
  };

  const getFallbackText = () => {
    // Get the first 3 to 4 words from displayedText or cleanedResponseHistory
    const fallbackText = displayedText || cleanedResponseHistory;
    return fallbackText.split(" ").slice(0, 4).join(" ");
  };

  return (
    <div className={`flex flex-col gap-4`} dir={textDirection} style={{direction: textDirection}}>
      <div className="flex flex-row items-center gap-3">
        <FontAwesomeIcon icon={faRandom} className="text-black" />

        <div className="text text-black font-bold text-lg">
          {conversation?.prompt !== "undefined"
            ? conversation?.prompt
            : getFallbackText()}
        </div>
      </div>
      <div className="text-base font-normal mb-5 ms-5">
        {/* {displayedText ? displayedText : cleanedResponseHistory} */}
        {(isLast && typewriting) || displayedText ? displayedText : cleanedResponseHistory ? cleanedResponseHistory : cleanedResponse }
      </div>
      {
        isLast && loading &&
        <>
        <SkeletonLoader/>
        </>
      }
    </div>
  );
};

export default ConversationComponent;
