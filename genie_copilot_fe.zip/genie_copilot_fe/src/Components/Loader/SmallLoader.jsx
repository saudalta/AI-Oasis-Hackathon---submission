import React from 'react';
import "./SmallLoader.css";

const SmallLoader = () => {
  return (
    <>
    <span class="loader"></span>
    </>
  )
}

export default SmallLoader