import 'react-loading-skeleton/dist/skeleton.css'
import Skeleton, {SkeletonTheme} from 'react-loading-skeleton';

const SkeletonLoader = () => {
    return (
        <div className={"p-3"}>
            {/* <SkeletonTheme baseColor="rgb(100,115,166)" highlightColor="rgb(10,16,40)"> */}
            <SkeletonTheme baseColor="#202020" highlightColor="#444">
                <p>
                    <Skeleton count={5}/>
                </p>
            </SkeletonTheme>
        </div>
    );
};

export default SkeletonLoader;
