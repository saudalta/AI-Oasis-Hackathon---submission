import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  faChartLine,
  faDiamond,
  faEye,
  faPaperclip,
  faSearch,
} from "@fortawesome/free-solid-svg-icons";

import {
  AUTH_ENDPOINTS,
  BASEURL,
  BASEURL1,
  ENDPOINTS,
} from "../../Axios/EndPoints";
import axios from "axios";
import { Post } from "../../Axios/Post";
import { determineDictionary } from "../../Lib/determineDictionary";
import ConversationComponent from "../../Components/ConversationComponent";
import { setSelectedDocument } from "../../Redux/Actions/DocumentAction";
import SkeletonLoader from "../../Components/Loader/SkeletonLoader";
// import { setSelectedDocument } from "../../Redux/Actions/DocumentAction";
import { setChatHistory, setNewChat, setNewChatID } from "../../Redux/Actions/NewChatAction";

const Home = () => {
  const dispatch = useDispatch();
  const languageStore = useSelector(
    (state) => state?.Language?.selectedLanguage
  );
  const documentStore = useSelector(
    (state) => state?.Document?.selectedDocument
  );
  const newChatStore = useSelector((state) => state?.NewChat.newChat);
  const newChatID = useSelector((state) => state?.NewChat?.chatID);

  const chatHistory = useSelector((state) => state?.NewChat?.chatHistory);
  const authStore = useSelector((state) => state?.LoginReducer);

  console.log("chatHistory >>", chatHistory);

  const [activeLanguage, setActiveLanguage] = useState(
    languageStore || "english"
  );
  const [inputLanguage, setInputLanguage] = useState("english");

  const [activeLanguageData, setActiveLanguageData] = useState(
    determineDictionary(activeLanguage)
  );

  const [searchQuery, setSearchQuery] = useState("");
  const [showResponse, setShowResponse] = useState(false);
  const [lastResponseIndex, setLastResponseIndex] = useState(-1);
  const [typewritingIndex, setTypewritingIndex] = useState(-1);

  const [chatNew, setChatNew] = useState(false || newChatStore);

  console.log("new chat >>", chatNew);

  const [file, setFile] = useState(null);
  // const [conversationHistory, setConversationHistory] = useState([]);
  const [loading, setLoading] = useState(false);

  const [currentPrompt, setCurrentPrompt] = useState("");
  const [currentResponse, setCurrentResponse] = useState("");

  // console.log("currentPrompt >>>", currentPrompt);
  // console.log("currentResponse >>>", currentResponse);
  // console.log("newChatID >>>", newChatID);

  useEffect(() => {
    setActiveLanguageData(determineDictionary(languageStore));
    setActiveLanguage(activeLanguage);
    // eslint-disable-next-line
  }, [languageStore]);

  // useEffect(() => {
  //   if (chatHistory && chatHistory?.length > 0) {
  //     setConversationHistory(chatHistory);
  //   }
  // }, [chatHistory]);

  useEffect(() => {
    if (newChatStore) {
      setChatNew(true);
      dispatch(setSelectedDocument(null));
    } else {
      setChatNew(false);
    }
    // eslint-disable-next-line
  }, [newChatStore]);

  // const createNewChat = async () => {
  //   const token = authStore?.token;

  //   try {
  //     const response = await axios.post(
  //       BASEURL1 + AUTH_ENDPOINTS.CREATE_CHAT,
  //       null,
  //       {
  //         headers: {
  //           Accept: "application/json",
  //           Authorization: "Bearer " + token,
  //           "Content-Type": "application/json",
  //           "ngrok-skip-browser-warning": true,
  //         },
  //       }
  //     );

  //     // console.log("API Response:", response?.data?.data);
  //     if (response?.data?.success) {
  //       // const newChatId = response?.data?.data?.chat_id;
  //       const newChatId = response?.data?.data?.id;
  //       dispatch(setChatHistory([])); // Clear chat history
  //       dispatch(setNewChat(true));
  //       dispatch(setNewChatID(newChatId));
  //       dispatch(setSelectedDocument(null));
  //     }
  //     // Handle success or other logic based on the response
  //   } catch (error) {
  //     console.error("API Error:", error?.response);
  //   }
  // };

  // useEffect(() => {
  //   if (newChatID === null || newChatID === "" || newChatID === "undefined") {
  //     createNewChat();
  //   }
  //   // eslint-disable-next-line
  // }, [newChatID === null || newChatID === "" || newChatID === "undefined"]);

  useEffect(() => {
    if (file) {
      uploadFile();
    }
    // eslint-disable-next-line
  }, [file]);

  // useEffect(() => {
  //   if (chatHistory && chatHistory?.length > 0) {
  //     setShowResponse(true);
  //     setShowResponse(true);
  //     setLastResponseIndex(chatHistory.length - 1);
  //     const latestChat = chatHistory[chatHistory?.length - 1];
  //     // console.log("latestChat >>>", latestChat)
  //     if (latestChat) {
  //       setCurrentPrompt(latestChat?.prompt);
  //       setCurrentResponse(latestChat?.response);
  //       createChatLogs(latestChat?.prompt, latestChat?.response);
  //     }
  //   }
  //   // eslint-disable-next-line
  // }, [chatHistory]);

  useEffect(() => {
    if (chatHistory && chatHistory?.length > 0) {
      setShowResponse(true);
      const latestChat = chatHistory[chatHistory?.length - 1];
      if (latestChat) {
        setCurrentPrompt(latestChat?.prompt);
        setCurrentResponse(latestChat?.response);
        createChatLogs(latestChat?.prompt, latestChat?.response);
        setTypewritingIndex(chatHistory?.length - 1);
      }
    }
    // eslint-disable-next-line
  }, [chatHistory]);

  const handleFileChange = (e) => {
    const selectedFile = e.target.files[0];
    // console.log("selectedFile >>>", selectedFile);
    setFile(selectedFile);
  };

  const uploadFile = () => {
    if (file) {
      const formData = new FormData();
      formData.append("file", file);

      // Replace 'YOUR_UPLOAD_API_ENDPOINT' with your actual API endpoint for file upload
      axios
        .post(`${BASEURL + ENDPOINTS.INGEST}`, formData, {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        })
        .then((response) => {
          // Handle the successful response
          console.log("Success:", response.data);
          setFile(null);
        })
        .catch((error) => {
          // Handle the error
          console.error("Error:", error);
        });
    } else {
      console.log("No file selected for upload");
    }
  };

  const submitWithoutFile = () => {
    setLoading(true);
    let completionData = {
      include_sources: false,
      prompt: searchQuery,
      stream: false,
      use_context: true,
      system_prompt: "You are a rapper. Always answer with a rap.",
    };

    let submitQuery = JSON.stringify(completionData);

    Post(`${ENDPOINTS.COMPLETIONS}`, submitQuery, false, "", false)
      .then((response) => {
        // console.log(
        //   "response from api is without doc >>>",
        //   response?.data?.choices
        // );
        const valueToDisplayPrompt = completionData?.prompt;
        const valueToDisplayResponse =
          response?.data?.choices[0]?.message?.content;

        setCurrentPrompt(valueToDisplayPrompt);
        setCurrentResponse(valueToDisplayResponse);

        // setConversationHistory((prevHistory) => [
        //   ...prevHistory,
        //   { prompt: valueToDisplayPrompt, response: valueToDisplayResponse },
        // ]);

        dispatch(
          setChatHistory([
            ...chatHistory,
            { prompt: valueToDisplayPrompt, response: valueToDisplayResponse },
          ])
        );

        setSearchQuery("");
        setLoading(false);
        // dispatch(setSelectedDocument(null));
      })
      .catch((error) => {
        console.log("error >>", error?.response);
        setLoading(false);
      });
  };

  const submitWithFile = () => {
    setLoading(true);
    let completionData = {
      context_filter: {
        docs_ids: [documentStore?.doc_id],
      },
      include_sources: true,
      messages: [
        {
          content: "You are a rapper. Always answer with a rap.",
          role: "system",
        },
        {
          content: searchQuery,
          role: "user",
        },
      ],
      stream: false,
      use_context: true,
    };

    let submitQuery = JSON.stringify(completionData);

    Post(
      `${ENDPOINTS.COMPLETIONS_WITH_DOCUMENTS}`,
      submitQuery,
      false,
      "",
      false
    )
      .then((response) => {
        // console.log(
        //   "response from api is with doc >>>",
        //   response?.data?.choices
        // );
        const valueToDisplayPrompt =
          completionData?.prompt !== "undefined"
            ? completionData?.prompt
            : "Document";
        const valueToDisplayResponse =
          response?.data?.choices[0]?.message?.content;

        setCurrentPrompt(valueToDisplayPrompt);
        setCurrentResponse(valueToDisplayResponse);

        // setConversationHistory((prevHistory) => [
        //   ...prevHistory,
        //   { prompt: valueToDisplayPrompt, response: valueToDisplayResponse },
        // ]);

        dispatch(
          setChatHistory([
            ...chatHistory,
            { prompt: valueToDisplayPrompt, response: valueToDisplayResponse },
          ])
        );

        setSearchQuery("");
        setLoading(false);
      })
      .catch((error) => {
        console.log("error >>", error?.response);
        setLoading(false);
      });
  };

  const handleSearch = () => {
    // Call your API with the searchQuery value
    // console.log("API call with search query:", searchQuery);
    setShowResponse(true);
    if (documentStore !== null || documentStore) {
      submitWithFile();
    } else {
      submitWithoutFile();
    }
  };

  const createChatLogs = async (prompt, response) => {
    const token = authStore?.token;

    const formData = new FormData();
    formData.append("chat_id", newChatID); // Assuming newChatStore holds the chat id
    formData.append("prompt", prompt);
    formData.append("system_prompt", response);
    formData.append("chat_time", new Date().toISOString()); // Current time in ISO format

    try {
      const response = await axios.post(
        BASEURL1 + AUTH_ENDPOINTS.CREATE_CHAT_HISTORY_LOGS,
        formData,
        {
          headers: {
            Accept: "application/json",
            Authorization: "Bearer " + token,
            "Content-Type": "multipart/form-data",
            "ngrok-skip-browser-warning": true,
          },
        }
      );

      // console.log("API Response:", response?.data?.data);
      if (response?.data?.success) {
        // const responseData = response?.data?.data;
        console.log("response is >>>>", response?.data?.data);
      }
      // Handle success or other logic based on the response
    } catch (error) {
      console.error("API Error:", error?.response);
    }
  };

  // const setConversationHistory = (history) => {
  //   dispatch(setChatHistory(history));
  // };

  return (
    <>
      <div className="flex-1 h-screen w-full relative">
        <div className="flex-1 bg-children w-children p-20 gap-2 prompt-container">
          {/* Your response content */}
          {showResponse ? (
            <>
              {/* {loading ? (
              <>
                <SkeletonLoader />
              </>
            ) : (
              <>
                {chatHistory && chatHistory?.length > 0 ? (
                  <>
                    {chatHistory.map((conversation, index) => (
                      <div key={index}>
                        <ConversationComponent conversation={conversation} />
                        {index === lastResponseIndex && loading && <SkeletonLoader />}
                      </div>
                    ))}
                    {chatHistory?.map((conversation, index) => (
                        <div key={index}>
                          <ConversationComponent
                            conversation={conversation}
                            typewriting={typewritingIndex === index}
                          />
                          {index < chatHistory.length - 1 && (
                            <SkeletonLoader />
                          )}
                        </div>
                      ))}
                  </>
                ) : (
                  <></>
                )}
              </>
            )} */}
            {
              loading && chatHistory?.length === 0 &&
              <>
                <SkeletonLoader />
              </>
            }
            {chatHistory && chatHistory?.length > 0 ? (
                  <>
                    {/* {chatHistory.map((conversation, index) => (
                      <div key={index}>
                        <ConversationComponent conversation={conversation} />
                        {index === lastResponseIndex && loading && <SkeletonLoader />}
                      </div>
                    ))} */}
                    {chatHistory?.map((conversation, index) => (
                        
                          <ConversationComponent
                          key={index}
                            conversation={conversation}
                            typewriting={typewritingIndex === index}
                            isLast={index === chatHistory.length - 1}
                            loading={loading}
                          />
                        
                      ))}
                  </>
                ) : (
                  <></>
                )}
            </>
          ) : (
            <>
              <div className="h-full flex items-center justify-end flex-col gap-2">
                <div className="flex items-center w-full justify-center text-black font-bold text-4xl">
                  {activeLanguageData?.Welcome}
                </div>
                <div className="flex items-center w-full justify-center text-black font-light text-base">
                  {activeLanguageData?.under_welcome}
                </div>
                <div className="mt-4 flex flex-row items-center justify-between w-full">
                  <div className="flex flex-col items-center gap-2 w-1/3 justify-center">
                    <FontAwesomeIcon
                      icon={faDiamond}
                      className="text-grey-500"
                    />
                    <div className="font-bold text-gray-600">
                      {activeLanguageData?.Clear_and_precise}
                    </div>
                    <div className=" font-medium text-gray-400 text-center">
                      {activeLanguageData?.under_Clear_and_precise}
                    </div>
                  </div>
                  <div className="flex flex-col items-center gap-2 w-1/3 justify-center">
                    <FontAwesomeIcon icon={faEye} className="text-grey-500" />
                    <div className="font-bold text-gray-600">
                      {activeLanguageData?.Personalized_answers}
                    </div>
                    <div className=" font-medium text-gray-400 text-center">
                      {activeLanguageData?.under_Personalized_answers}
                    </div>
                  </div>
                  <div className="flex flex-col items-center gap-2 w-1/3 justify-center">
                    <FontAwesomeIcon
                      icon={faChartLine}
                      className="text-grey-500"
                    />
                    <div className="font-bold text-gray-600">
                      {activeLanguageData?.Increased_efficiency}
                    </div>
                    <div className=" font-medium text-gray-400 text-center">
                      {activeLanguageData?.under_Increased_efficiency}
                    </div>
                  </div>
                </div>
              </div>
            </>
          )}
        </div>

        <div className="h-16 absolute bottom-0 left-0 w-full px-20 my-10">
          <div className="flex items-center gap-3 w-full">
            <div className="relative">
              {/* Label for file input */}
              <label htmlFor="fileInput" className="cursor-pointer text-black">
                <FontAwesomeIcon icon={faPaperclip} />
                <input
                  type="file"
                  id="fileInput"
                  style={{ display: "none" }}
                  onChange={handleFileChange}
                />
              </label>
            </div>
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSearch();
              }}
              className="flex items-center gap-3 w-full"
            >
              <div className="relative flex-grow">
                <input
                  type="search"
                  placeholder="Example: 'Explain quantum computing in simple terms'"
                  value={searchQuery}
                  onChange={(e) => {
                    setSearchQuery(e.target.value);

                    // Determine language based on the input value
                    const language = e.target.value.match(/[\u0600-\u06FF]/)
                      ? "arabic"
                      : "english";
                    setInputLanguage(language);
                  }}
                  className={`w-full bg-transparent py-4 px-5 pr-10 rounded-full border border-1 ${
                    inputLanguage === "arabic" ? "rtl" : "ltr"
                  }`}
                />
                <FontAwesomeIcon
                  icon={faSearch}
                  onClick={handleSearch}
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 cursor-pointer text-black"
                />
              </div>
            </form>
          </div>
        </div>
      </div>
    </>
  );
};

export default Home;
