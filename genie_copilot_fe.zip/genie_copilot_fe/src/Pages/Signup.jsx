import React from "react";
import LoginSignupHeader from "../Components/ReuseableComponents/Headers/LoginSignupHeader";
import SignupForm from "../Components/ReuseableComponents/Forms/SignupForm";

const Signup = () => {
  return (
    <div className="min-h-full h-screen flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-8">
        <LoginSignupHeader
          heading="Signup to create an account"
          paragraph="Already have an account? "
          linkName="Login"
          linkUrl="/"
        />
        <SignupForm />
      </div>
    </div>
  );
};

export default Signup;
